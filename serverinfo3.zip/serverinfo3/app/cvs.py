from xlsxwriter import Workbook
import sqlite3
import os
basedir = os.path.abspath('.') + '/serverinfo.db'

def create_xlsx_file(file_path: str, headers: dict, items: list):
    with Workbook(file_path) as workbook:
        worksheet = workbook.add_worksheet()
        worksheet.write_row(row=0, col=0, data=headers.values())
        header_keys = list(headers.keys())
        for index, item in enumerate(items):
            row = map(lambda field_id: item.get(field_id, ''), header_keys)
            worksheet.write_row(row=index + 1, col=0, data=row)


def exl():
    conn = sqlite3.connect(basedir)
    cur = conn.cursor()
    qry = cur.execute('SELECT * FROM owner;').fetchall()
    cur.close()
    headers = {
      'id': 'Id',
      'name': 'Name',
      'server': 'Server',
      'location': 'Location',
      'os': 'OS'
     }

    items = []
    e = {}
    for i in qry:
        e['id'] = i[0]
        e['name'] = i[1]
        e['server'] = i[2]
        e['location'] = i[3]
        e['os'] = i[4]
        items.append(dict(e))



    create_xlsx_file("app/my-xlsx-file.xlsx", headers, items)

if __name__ == '__main__':
    exl()
