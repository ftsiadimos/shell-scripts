from flask_table import Table, Col, LinkCol

class Results(Table):
    id = Col('Id', show=False)
    name = Col('Owner')
    server = Col('Server')
#    location = Col('Location')
    os = Col('OS')
#    lifecycle = Col('Lifecycle')
#    last_report = Col('Last_report')
    more = LinkCol('More', 'more', url_kwargs=dict(id='id'))
    edit = LinkCol('Edit', 'edit', url_kwargs=dict(id='id'))
    delete = LinkCol('Delete', 'delete', url_kwargs=dict(id='id'))

class ResultsUser(Table):
    id = Col('Id', show=False)
    username = Col('username')
    email = Col('email')
    edit = LinkCol('Edit', 'editU', url_kwargs=dict(id='id'))
    delete = LinkCol('Delete', 'deleteU', url_kwargs=dict(id='id'))
