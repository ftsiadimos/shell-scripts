# main.py

from app import app
from app import db
from app.forms import SearchForm, ServerForm, LoginForm, RegistrationForm, Edituser
from flask import flash, render_template, request, redirect, url_for, send_file, jsonify
from app.models import Owner, User
from app.tables import Results, ResultsUser
from flask_login import logout_user, login_required, current_user, login_user
from werkzeug.urls import url_parse
import requests, base64
from app.sat import sat
from multiprocessing import Process
from flask_marshmallow import Marshmallow
from flask_restful import Api, Resource
ma = Marshmallow(app)
api = Api(app)
from app.cvs import exl

#----------------API-----------------------
def satauth():
    url = 'https://foreman.agonyweb.com/api/hosts?per_page=900'
    headers = {'Content-Type': 'application/json,version=2'}
    passs = base64.b64decode("QWdvbnkhQCM=")
    usersat = 'fotis'
    return(url, headers, passs, usersat)

def syncsathost(serverf):
    url, headers, passs, usersat = satauth()
    r = requests.get(url, headers=headers, params={'search':'name='+serverf }, auth=(usersat, passs), verify=False)

    # Process results.
    response_dict = r.json()
    repo_dicts = response_dict['results']
    qry = db.session.query(Owner).filter(Owner.server==serverf)
    owner = qry.first()
    for repo_dict in repo_dicts:
        if repo_dict['name'] == serverf:
            owner.location = repo_dict['organization_name']
            owner.os = repo_dict['operatingsystem_name']
            owner.lifecycle = repo_dict['environment_name']
            owner.last_report = repo_dict['last_report']
            db.session.commit()




class PostSchema(ma.Schema):
    class Meta:
        fields = ("id", "name", "server")


post_schema = PostSchema()
posts_schema = PostSchema(many=True)


class PostListResource(Resource):
    def get(self):
        posts = Owner.query.all()
        return posts_schema.dump(posts)

    def post(self):
        new_post = Owner(
            name=request.json['name'],
            server=request.json['server']
         )
        serverf=request.json['server']
        db.session.add(new_post)
        db.session.commit()
        heavy_process = Process(target=syncsathost(serverf),daemon=True)
        heavy_process.start()
        #syncsathost(serverf)
        return post_schema.dump(new_post)


class PostResource(Resource):
    def get(self, post_id):
        post = Owner.query.get_or_404(post_id)
        return post_schema.dump(post)

    def patch(self, post_id):
        post = Owner.query.get_or_404(post_id)

        if 'name' in request.json:
            post.name = request.json['name']
        if 'server' in request.json:
            post.server = request.json['server']
        db.session.commit()
        return post_schema.dump(post)

    def delete(self, post_id):
        post = Owner.query.get_or_404(post_id)
        db.session.delete(post)
        db.session.commit()
        return '', 204


api.add_resource(PostListResource, '/api')
api.add_resource(PostResource, '/api/<int:post_id>')

#----------------API-END-----------------------


# @app.route('/download')
# def downloadFile():
    #For windows you need to use drive name [ex: F:/Example.pdf]
#     path = "my-xlsx-file.xlsx"
#     return send_file(path, as_attachment=True, cache_timeout=0)

def syncsat():
    url, headers, passs, usersat = satauth()
    r = requests.get(url, headers=headers, auth=(usersat, passs), verify=False)

    # Process results.
    response_dict = r.json()
    repo_dicts = response_dict['results']
    for repo_dict in repo_dicts:
        a = db.session.query(Owner.id).filter_by(server=repo_dict['name']).first()
        if a is None:
            owner = Owner()
            owner.server  = repo_dict['name']
            owner.location = repo_dict['organization_name']
            owner.os = repo_dict['operatingsystem_name']
            owner.lifecycle = repo_dict['environment_name']
            owner.last_report = repo_dict['last_report']
            db.session.add(owner)
            db.session.commit()
    return(flash('Sync is finshed!'))


@app.route('/', methods=['GET', 'POST'])
@login_required
def index():
    search = SearchForm(request.form)
    if request.method == 'POST':
        if request.form['submit_button'] == 'satellite-sync':
            heavy_process = Process(
                target=syncsat,
                daemon=True
            )
            heavy_process.start()
            #heavy_process.join()
            flash('Sync is finshed!')
        if request.form['submit_button'] == 'satellite-graph':
            sat()
            return render_template('python_repos.html')
        if request.form['submit_button'] == 'Export-excel':
            exl()
            path = "my-xlsx-file.xlsx"
            return send_file(path, as_attachment=True, cache_timeout=0)
            flash('Excel has exported!')
        if request.form['submit_button'] == 'Search':
            return search_results(search)

    return render_template('index.html', form=search)


@app.route('/results')
def search_results(search):
    results = []
    search_string = search.data['search']

    if search_string:
        if search.data['select'] == 'Owner':
            qry = db.session.query(Owner).filter(
                    Owner.name.contains(search_string))
            results = qry.all()
        elif search.data['select'] == 'Servers':
            qry = db.session.query(Owner).filter(
                Owner.server.contains(search_string))
            results = qry.all()
        else:
            qry = db.session.query(Owner)
            results = qry.all()
    else:
        qry = db.session.query(Owner).order_by(Owner.server)
        results = qry.all()

    if not results:
        flash('No results found!')
        return redirect('/')
    else:
        table = Results(results)
        table.border = True
        return render_template('results.html', table=table)


@app.route('/new_server', methods=['GET', 'POST'])
@login_required
def new_server():
    """
    Add a new server
    """
    form = ServerForm(request.form)

    if request.method == 'POST' and form.validate():
        server = Owner()
        save_changes(server, form, new=True)
        flash('Servers created successfully!')
        return redirect('/')

    return render_template('new_server.html', form=form)


def save_changes(server, form, new=False):
    """
    Save the changes to the database
    """
    owner = Owner()
    owner.name = form.name.data
    owner.server = form.server.data
    owner.location = form.location.data
    owner.os = form.os.data
    owner.lifecycle = form.lifecycle.data
    owner.last_report = form.last_report.data
    owner.text = form.text.data
    if new:
        # Add the new server to the database
        db.session.add(owner)

    # commit the data to the database
    db.session.commit()



@app.route('/items/<int:id>', methods=['GET', 'POST'])
@login_required
def more(id):
    """
    Add / edit an item in the database
    """
    qry = db.session.query(Owner).filter(
                Owner.id==id)
    server = qry.first()

    if server:
        form = ServerForm(formdata=request.form, obj=server)
        if request.method == 'POST':
            if request.form['submit'] == 'Update':
                heavy_process = Process(target=syncsathost(server.server),daemon=True)
                heavy_process.start()
                #syncsathost(server.server)
                flash('Server updated successfully!')
                return redirect('/')
        return render_template('more.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)




@app.route('/item/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    """
    Add / edit an item in the database
    """
    qry = db.session.query(Owner).filter(
                Owner.id==id)
    server = qry.first()

    if server:
        form = ServerForm(formdata=request.form, obj=server)
        if request.method == 'POST' and form.validate():
            if request.form['submit'] == 'Submit':
                server.name = form.name.data
                server.server = form.server.data
                server.location = form.location.data
                server.os = form.os.data
                server.lifecycle = form.lifecycle.data
                server.last_report = form.last_report.data
                server.text = form.text.data
                db.session.commit()
                flash('Server updated successfully!')
                return redirect('/')
        return render_template('edit_server.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)


@app.route('/delete/<int:id>', methods=['GET', 'POST'])
@login_required
def delete(id):
    """
    Delete the item in the database that matches the specified
    id in the URL
    """
    qry = db.session.query(Owner).filter(
        Owner.id==id)
    server = qry.first()

    if server:
        form = ServerForm(formdata=request.form, obj=server)
        if request.method == 'POST':
            # delete the item from the database
            db.session.delete(server)
            db.session.commit()

            flash('Server deleted successfully!')
            return redirect('/')
        return render_template('delete_server.html', form=form)
    else:
        return 'Error deleting #{id}'.format(id=id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index')
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you have registered a user!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    qry = db.session.query(User).all()
    table = ResultsUser(qry)
    table.border = True
    return render_template('admin.html', table=table)


@app.route('/deleteU/<int:id>', methods=['GET', 'POST'])
@login_required
def deleteU(id):
    """
    Delete the item in the database that matches the specified
    id in the URL
    """
    qry = db.session.query(User).filter(
        User.id==id)
    server = qry.first()
    if server:
        form = Edituser(formdata=request.form, obj=server)
        if request.method == 'POST':
            db.session.delete(server)
            db.session.commit()

            flash('User deleted successfully!')
            return redirect('/')
        return render_template('delete_user.html', form=form)
    else:
        return 'Error deleting #{id}'.format(id=id)

@app.route('/editU/<int:id>', methods=['GET', 'POST'])
@login_required
def editU(id):
    """
    Add / edit an item in the database
    """
    qry = db.session.query(User).filter(
                User.id==id)
    user = qry.first()

    if user:
        form = Edituser(formdata=request.form, obj=user)
        if form.validate_on_submit():
            user.username = form.username.data
            user.email = form.email.data
            user.set_password(form.password.data)
            db.session.commit()
            flash('User updated successfully!')
            return redirect('/')
        return render_template('editU.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0', port=5002)
