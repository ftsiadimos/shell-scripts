# forms.py
from flask_wtf import FlaskForm
from wtforms import Form, StringField, SelectField, validators, PasswordField, BooleanField, SubmitField, TextAreaField
from wtforms.validators import ValidationError, DataRequired, Email, EqualTo
from app.models import User

class SearchForm(Form):
    choices = [('Servers', 'Server'), ('Owner', 'Owner')]
    select = SelectField('Search By:', choices=choices)
    search = StringField('')


class ServerForm(Form):
    lifecycle = [('Production', 'Production'),
                   ('Staging', 'Staging')
                   ]
    name = StringField('Owner')
    server = StringField('Server')
    location = StringField('Location')
    os = StringField('OS')
    lifecycle = SelectField('Lifecycle', choices=lifecycle)
    last_report = StringField('Last_report')
    text = TextAreaField('Text')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')


class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField(
        'Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')


class Edituser(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField(
        'Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Save')
