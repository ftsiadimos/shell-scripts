#!/usr/bin/env python3
import requests
#import pdfkit
import base64
from plotly.graph_objs import Bar
from plotly import offline
from datetime import datetime

def sat():
    # Make an API call and store the response.
    url = 'https://foreman.agonyweb.com/api/statistics'
    headers = {'Content-Type': 'application/json'}
    passs = base64.b64decode("QWdvbnkhQCM=")
    r = requests.get(url, headers=headers, auth=('fotis',passs ), verify=False)
    print(f"Status code: {r.status_code}")

    # Process results.
    response_dict = r.json()
    repo_dicts = response_dict['os_count']
    repo_env = response_dict['env_count']
    #sort_orders = sorted(repo_dicts.key(), key=lambda x: x[0])


    sa, ss, sc, sb = [], [], [], []
    for repo_dict in repo_dicts:
        sa.append(repo_dict['label'])
        ss.append(repo_dict['data'])

    for repo_dict in repo_env:
        sc.append(repo_dict['label'])
        sb.append(repo_dict['data'])

    sa.extend(sc)
    ss.extend(sb)
    now = datetime.now()
    # Make visualization.
    data = [{
        'type': 'bar',
        'x': sa,
        'y': ss,
        #    'hovertext': dd,
        'marker': {
            'color': 'rgb(60, 100, 150)',
            'line': {'width': 1.5, 'color': 'rgb(25, 25, 25)'}
     },
        'opacity': 0.6,
    }]

    my_layout = {
        'title': 'Satellite Hosts ' + str(now),
        'titlefont': {'size': 28},
        'xaxis': {
           'title': 'Hosts OS',
           'titlefont': {'size': 24},
           'tickfont': {'size': 14},
         },
        'yaxis': {
            'title': 'Total Hosts',
            'titlefont': {'size': 24},
            'tickfont': {'size': 14},
        },

    }

    pdfkit_options = {'dpi': 900,
               "page-size": "letter",
               "orientation": "Landscape",
               'zoom': 1.045,
          }

    fig = {'data': data, 'layout': my_layout}
    offline.plot(fig, filename='app/templates/python_repos.html', auto_open=False)
    ##pdfkit.from_file('templates/python_repos.html', 'templates/out.pdf', options=pdfkit_options)

if __name__ == '__main__':
    sat()
