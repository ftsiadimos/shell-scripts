from sqlalchemy import create_engine, ForeignKey
from sqlalchemy import Column, Date, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, backref

engine = create_engine('sqlite:///serverinfo.db', echo=True)
Base = declarative_base()


class Owner(Base):
    __tablename__ = "owner"

    id = Column(Integer, primary_key=True)
    name = Column(String)

    def __repr__(self):
        return "<Owner: {}>".format(self.name)


class Servers(Base):
    """"""
    __tablename__ = "servers"

    id = Column(Integer, primary_key=True)
    server = Column(String)
    location = Column(String)
    os = Column(String)
    lifecycle = Column(String)
    last_report = Column(String)

    owner_id = Column(Integer, ForeignKey("owner.id"))
    owner = relationship("Owner", backref=backref(
        "servers", order_by=id))

class User(Base):
    __tablename__ = "user"
    id = Column(Integer, primary_key=True)
    username = Column(String(64), index=True, unique=True)
    email = Column(String(120), index=True, unique=True)
    password_hash = Column(String(128))


# create tables
Base.metadata.create_all(engine)
