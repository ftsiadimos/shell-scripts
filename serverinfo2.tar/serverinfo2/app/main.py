# main.py

from app import app
from app import db
from app.forms import SearchForm, ServerForm, LoginForm, RegistrationForm, Edituser
from flask import flash, render_template, request, redirect, url_for, send_file
from app.models import Owner, Servers, User
from app.tables import Results, ResultsUser
from flask_login import logout_user, login_required, current_user, login_user
from werkzeug.urls import url_parse
import requests, base64
from app.sat import sat



@app.route('/download')
def downloadFile():
    #For windows you need to use drive name [ex: F:/Example.pdf]
    path = "templates/out.pdf"
    return send_file(path, as_attachment=True)

def syncsat():
    url = 'https://foreman.agonyweb.com/api/hosts'
    headers = {'Content-Type': 'application/json'}
    passs = base64.b64decode("QWdvbnkhQCM=")
    r = requests.get(url, headers=headers, auth=('fotis',passs ), verify=False)
    print(f"Status code: {r.status_code}")

    # Process results.
    response_dict = r.json()
    repo_dicts = response_dict['results']
    for repo_dict in repo_dicts:
        a = db.session.query(Servers.id).filter_by(server=repo_dict['name']).first()
        if a is None:
            owner = Owner()
            server = Servers()
            owner.name = ""
            server.owner = owner
            server.server  = repo_dict['name']
            server.location = repo_dict['organization_name']
            server.os = repo_dict['operatingsystem_name']
            server.lifecycle = repo_dict['environment_name']
            server.last_report = repo_dict['last_report']
            db.session.add(server)
            db.session.commit()
    flash('Sync is finshed!')


@app.route('/', methods=['GET', 'POST'])
@login_required
def index():
    search = SearchForm(request.form)
    if request.method == 'POST':
        if request.form['submit_button'] == 'satellite-sync':
            syncsat()
        if request.form['submit_button'] == 'satellite-metrix':
            sat()
            return render_template('python_repos.html')
        if request.form['submit_button'] == 'Search':
            return search_results(search)

    return render_template('index.html', form=search)


@app.route('/results')
def search_results(search):
    results = []
    search_string = search.data['search']

    if search_string:
        if search.data['select'] == 'Owner':
            qry = db.session.query(Servers, Owner).filter(
                Owner.id==Servers.owner_id).filter(
                    Owner.name.contains(search_string))
            results = [item[0] for item in qry.all()]
        elif search.data['select'] == 'Servers':
            qry = db.session.query(Servers).filter(
                Servers.server.contains(search_string))
            results = qry.all()
        else:
            qry = db.session.query(Servers)
            results = qry.all()
    else:
        qry = db.session.query(Servers).order_by(Servers.server)
        results = qry.all()

    if not results:
        flash('No results found!')
        return redirect('/')
    else:
        # display results
        table = Results(results)
        table.border = True
        return render_template('results.html', table=table)


@app.route('/new_server', methods=['GET', 'POST'])
@login_required
def new_server():
    """
    Add a new server
    """
    form = ServerForm(request.form)

    if request.method == 'POST' and form.validate():
        # save the server
        server = Servers()
        save_changes(server, form, new=True)
        flash('Servers created successfully!')
        return redirect('/')

    return render_template('new_server.html', form=form)


def save_changes(server, form, new=False):
    """
    Save the changes to the database
    """
    # Get data from form and assign it to the correct attributes
    # of the SQLAlchemy table object
    owner = Owner()
    owner.name = form.owner.data

    server.owner = owner
    server.server = form.server.data
    server.location = form.location.data
    server.os = form.os.data
    server.lifecycle = form.lifecycle.data
    server.last_report = form.last_report.data
    if new:
        # Add the new server to the database
        db.session.add(server)

    # commit the data to the database
    db.session.commit()


@app.route('/item/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    """
    Add / edit an item in the database
    """
    qry = db.session.query(Servers).filter(
                Servers.id==id)
    server = qry.first()

    if server:
        form = ServerForm(formdata=request.form, obj=server)
        if request.method == 'POST' and form.validate():
            # save edits
            save_changes(server, form)
            flash('Server updated successfully!')
            return redirect('/')
        return render_template('edit_server.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)


@app.route('/delete/<int:id>', methods=['GET', 'POST'])
@login_required
def delete(id):
    """
    Delete the item in the database that matches the specified
    id in the URL
    """
    qry = db.session.query(Servers).filter(
        Servers.id==id)
    server = qry.first()

    if server:
        form = ServerForm(formdata=request.form, obj=server)
        if request.method == 'POST':
            # delete the item from the database
            db.session.delete(server)
            db.session.commit()

            flash('Server deleted successfully!')
            return redirect('/')
        return render_template('delete_server.html', form=form)
    else:
        return 'Error deleting #{id}'.format(id=id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('index')
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
#    if current_user.is_authenticated:
#        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you have registered a user!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    qry = db.session.query(User).all()
    table = ResultsUser(qry)
    table.border = True
    return render_template('admin.html', table=table)


@app.route('/deleteU/<int:id>', methods=['GET', 'POST'])
@login_required
def deleteU(id):
    """
    Delete the item in the database that matches the specified
    id in the URL
    """
    qry = db.session.query(User).filter(
        User.id==id)
    server = qry.first()
    if server:
        form = Edituser(formdata=request.form, obj=server)
        if request.method == 'POST':
            db.session.delete(server)
            db.session.commit()

            flash('User deleted successfully!')
            return redirect('/')
        return render_template('delete_user.html', form=form)
    else:
        return 'Error deleting #{id}'.format(id=id)

@app.route('/editU/<int:id>', methods=['GET', 'POST'])
@login_required
def editU(id):
    """
    Add / edit an item in the database
    """
    qry = db.session.query(User).filter(
                User.id==id)
    user = qry.first()

    if user:
        form = Edituser(formdata=request.form, obj=user)
        if form.validate_on_submit():
            # save edits
            username=form.username.data
            email=form.email.data
            print(user)
            print(form.password.data)
            user.set_password(form.password.data)
            db.session.commit()
            flash('User updated successfully!')
            return redirect('/')
        return render_template('editU.html', form=form)
    else:
        return 'Error loading #{id}'.format(id=id)

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0', port=5002)
