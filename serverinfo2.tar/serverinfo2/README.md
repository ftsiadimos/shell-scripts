# In DOckerFile we can run falsk instaed python

```
Example:

FROM python:3.7-alpine
WORKDIR /code
ENV FLASK_APP=app.py
ENV FLASK_RUN_HOST=0.0.0.0
RUN apk add --no-cache gcc musl-dev linux-headers
COPY requirements.txt requirements.txt
RUN pip install -r requirements.txt
EXPOSE 5000
COPY . .
CMD ["flask", "run"]
```

# Add manually records to db
```
from app import db
from app.models import User, Post
Start by creating a new user:

u = User(username='susan', email='susan@example.com')
u.set_password('mypassword')
u.check_password('anotherpassword')
db.session.add(u)
db.session.commit()
```

# Flask shell
```
After you add the shell context processor function you can work with database entities without having to import them:

(venv) $ flask shell
>>> db
<SQLAlchemy engine=sqlite:////Users/migu7781/Documents/dev/flask/microblog2/app.db>
>>> User
<class 'app.models.User'>
>>> Post
<class 'app.models.Post'>
```

# Upgrade new schema in the db
```
flask db init  <-- create the migrate folder
flask db migrate -m "users table"  <-- create the shema in the database
You will find that it has two functions called upgrade() and downgrade().
The flask db migrate command does not make any changes to the database, 
it just generates the migration script. To apply the changes to the database, the flask db upgrade command must be used.
flask db upgrade
```



